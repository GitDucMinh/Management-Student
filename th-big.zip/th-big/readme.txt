== Theme: Th Big ==
Contributors: ThemeHunk
Tags: e-commerce, blog, grid-layout, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, add_editor_style, featured-image-header, featured-images, footer-widgets, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready.
Requires at least: WordPress 4.7
Requires PHP: 5.6
Tested up to: 5.8
Stable tag: 1.0.1
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html


== Description ==
Th Big is a professional child theme of Big Store Theme. It is a Free Fully Responsive eCommerce WordPress theme specially designed for Shopping websites. Theme contains multiple sections along with Header and footer layout combinations, Color and Background option etc. Theme is Best suited for websites like gadget store, jewelry shop, electronic, food, home appliances site, fashion shop, furniture, grocery, clothing etc. Theme is deeply integrated with WooCommerce plugin to sell your products online. Check Out Demo – https://themehunk.com/product/big-store/#tabfix
For more information about Theme https://www.themehunk.com

== Frequently Asked Questions ==

= Does your theme support builder =
Yes our theme supports builder

= Can i use your theme with latest version of WordPress=
Yes, this theme is tested with latest version of WordPress, you can use it for your site.

== Changelog ==
= 1.0.1 =
* Links changed.

= 1.0.0 =
* Released: Nov 9, 2021

== Upgrade Notice ==
= 1.0.1 =
* Links changed.

== Resources ==
== Screenshots ==
1. Image used in Screenshots.
Image Name: screenshot.png

https://wordpress.org/plugins/woocommerce/
All are WooCommerce Sample Data Image
License: GPLv3

== Theme License & Copyright ==
Th Big is distributed under the terms of the GNU GPL
Big-Store-Copyright 2020, themehunk.com
License : GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html


==  Other Licenses ==
Other js files are self coded.

Once again, thank you so much for trying the Th Big WordPress Theme. We will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.